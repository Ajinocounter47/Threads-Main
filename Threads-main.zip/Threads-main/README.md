# Threads Brute Force Premium - From Indonesian
I created the Threads script with the aim of learning, you should read the terms and conditions for using this tool, I as a developer is not responsible if something unexpected happens.
<p align="left"><img src="Data/Threads.jpg"/></p>

[![GitHub watchers](https://img.shields.io/github/watchers/rozhakxd/Threads.svg?style=social&label=Watch)](https://GitHub.com/rozhakxd/Threads/watchers/)
[![GitHub forks](https://img.shields.io/github/forks/rozhakxd/Threads.svg?style=social&label=Fork)](https://GitHub.com/rozhakxd/Threads/network/)
[![GitHub stars](https://img.shields.io/github/stars/rozhakxd/Threads.svg?style=social&label=Star)](https://GitHub.com/rozhakxd/Threads/stargazers/)


##

### Description
**Threads** is a python script that functions to guess passwords on Threads, apart from that this script is a complement to [Facebook](https://github.com/RozhakXD/Facemash) and [Instagram](https://github.com/RozhakXD/Premium) which were previously made. You can use Apikey from the [InstaKey](https://instakey.rozhak.xyz/register/) website, you can say it can be used in three scripts at once.

##
  
### Installation

- **[Linux](https://drive.google.com/file/d/1HJU0rAjP_Sq3QJJFkigIrEuDJ-xUuniA/view?usp=drive_link) - [Termux](https://f-droid.org/repo/com.termux_118.apk)**

  ```
  >> apt update -y && apt upgrade -y
  >> pkg install git python-pip 
  >> git clone https://github.com/RozhakXD/Threads
  >> cd "Threads"
  >> python -m pip install --upgrade pip
  >> python -m pip install -r requirements.txt
  >> python Run.py
  ```
  - **Running on Termux**
  
    ```
    >> cd "$HOME/Threads"
    >> python Run.py
    ```

##

### Getting Successful Results

- Using good user-agents such as : **REALME, OPPO, POCO, XIAOMI, SAMSUNG, INFINIX, ONEPLUS, PIXEL, NEXUS, HUAWEI.**
- Search for the target account in the Threads app search recommendations.
- Use good methods like : **Instagram Apps or Threads Apps.**
- I hope you use a single user-agent so you can see which is a good user-agent.
- Noted for now only new accounts and small follower accounts are successful.

### No Results?

- The target you entered is not good or the password they used is a combination of special characters.
- You don't play **"Airplane Mode"** it is recommended to turn on at 200 username.
- Wrong password selection. Use the recommended password is **DEFAULT, COMPLETE** or number **01, 02**.

### Open Checkpoint Results?

- Only works on accounts that are online and the owner has confirmed **"Yes it's me"!**
- First wait about 1-7 days or 30 days after cracking.
- Run the script then select number One or **"Crack Hasil Checkpoint".**
- Enter the name of the file you want to crack **"dir Results"** to find out the file name.

### Why Can't Use WIFI?

- WiFi causes your IP address to be blocked or spam.
- Not getting a Success or Checkpoint result.
- WiFi causes it to get stuck at the words **"HIDUPKAN MODE PESAWAT 2 DETIK".**

### I Only Got Checkpoints?

- Instagram's security is getting tighter and they update all the time.
- Wrong selection of user-agent and method.
- Your provider may have a problem.
- The target that you entered is not good or has been cracked by someone.

### Account Always Logged Out?

- Accounts must include information such as name, biography and profile photo.
- Change the password on your Instagram account.
- Use a fresh cracked account from Instagram.
- Post a few photos every day so you don't think it's a fake account.
- Before logging in to Termux the account was logged in to the Threads application and was online.

##

### Screenshots

![Results/Ok-31-July-2023.txt](https://github.com/RozhakXD/Threads/blob/main/Data/Ok-31-July-2023.png)

##

### [Results Cannot Be Logged In?](https://drive.google.com/file/d/10kp-862cR3HOuvWRqGx--ZM-Wg-0IG4d/view?usp=drive_link)

- Do not log in to the browser if the account is the result of the **"Application"** method.
- Login using cracked cookies.
- Login to the latest version of the Instagram or Threads clone application.
- Turn on **"Airplane Mode"** before logging in.

##

~~~python
print("Happy Hacking Day !")
~~~
